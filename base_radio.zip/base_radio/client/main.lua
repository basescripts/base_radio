local RadioOpen = false
local RadioChannel = '0 (OFF)'
local RadioVolume = Config.radio_default_volume

function toggleRadioAnimation(state)
    lib.requestAnimDict('cellphone@')
	if state then
		TriggerEvent("attachItemRadio","radio01")
		TaskPlayAnim(PlayerPedId(), "cellphone@", "cellphone_text_read_base", 2.0, 3.0, -1, 49, 0, 0, 0, 0)
		radioProp = CreateObject(`prop_cs_hand_radio`, 1.0, 1.0, 1.0, 1, 1, 0)
		AttachEntityToEntity(radioProp, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 57005), 0.14, 0.01, -0.02, 110.0, 120.0, -15.0, 1, 0, 0, 0, 2, 1)
	else
		StopAnimTask(PlayerPedId(), "cellphone@", "cellphone_text_read_base", 1.0)
		ClearPedTasks(PlayerPedId())
		DeleteObject(radioProp)
		radioProp = 0
	end
end

RegisterNetEvent('base_radio:set_vol')
AddEventHandler('base_radio:set_vol', function()
	local input = lib.inputDialog(TranslateCap('menu_dialog_volume'), {'0 - 100 %'})
	if not input then toggleRadio() end
	RadioVolume = tonumber(input[1])
	if RadioVolume == nil or RadioVolume < 0 or RadioVolume > 100 then
		RadioVolume = Config.radio_default_volume
		toggleRadio()
	else
		toggleRadio()
		exports['pma-voice']:setRadioVolume(RadioVolume)
	end
end)

RegisterNetEvent('base_radio:set_freq')
AddEventHandler('base_radio:set_freq', function()
    local input = lib.inputDialog(TranslateCap('menu_dialog_frequency'), {'1 - ' .. Config.maximum_frequency})
	if not input then toggleRadio() end
    RadioChannel = tonumber(input[1])
	if RadioChannel == nil or RadioChannel < 1 or RadioChannel > Config.maximum_frequency then
		RadioChannel = '0 (OFF)'
		toggleRadio()
		RadioOpen = false
	else
		if RadioChannel == nil or RadioChannel < 1 or RadioChannel < Config.restricted_channels + 1 then
            for i=1, #Config.restricted_channels_jobs_allowed, 1 do
                if ESX.PlayerData.job.name == Config.restricted_channels_jobs_allowed[1] or ESX.PlayerData.job.name == Config.restricted_channels_jobs_allowed[2] or ESX.PlayerData.job.name == Config.restricted_channels_jobs_allowed[3] or ESX.PlayerData.job.name == Config.restricted_channels_jobs_allowed[4] or ESX.PlayerData.job.name == Config.restricted_channels_jobs_allowed[5] then
                    toggleRadio()
                    exports['pma-voice']:setVoiceProperty('radioEnabled', true)
                    exports['pma-voice']:setVoiceProperty('micClicks', true)
                    exports['pma-voice']:setRadioChannel(RadioChannel)
                    RadioOpen = true
                else
                    RadioChannel = '0 (OFF)'
                    toggleRadio()
                    RadioOpen = false
                end
            end
		else
			toggleRadio()
			exports['pma-voice']:setVoiceProperty('radioEnabled', true)
			exports['pma-voice']:setVoiceProperty('micClicks', true)
			exports['pma-voice']:setRadioChannel(RadioChannel)
			RadioOpen = true
		end
	end
end)

RegisterNetEvent('base_radio:use')
AddEventHandler('base_radio:use', function()
    toggleRadio()
end)

RegisterNetEvent('base_radio:leave')
AddEventHandler('base_radio:leave', function()
	exports['pma-voice']:setVoiceProperty('radioEnabled', false)
	exports['pma-voice']:setVoiceProperty('micClicks', false)
	exports["pma-voice"]:SetRadioChannel(0)
	exports["pma-voice"]:removePlayerFromRadio()
	toggleRadioAnimation(false)
	RadioChannel = '0 (OFF)'
	RadioOpen = false
end)

function toggleRadio()
	toggleRadioAnimation(false)
    toggleRadioAnimation(true)
	lib.registerContext({
		id = 'radio_menu',
		title = TranslateCap('menu_title'),
		onExit = function()
			toggleRadioAnimation(false)
		end,
		options = {
			{
				title = TranslateCap('menu_frequency') .. ' ' .. RadioChannel,
				arrow = true,
				event = 'base_radio:set_freq',
                icon = 'fa-solid fa-walkie-talkie',
			},
            {
				title = TranslateCap('menu_volume') .. ' ' .. RadioVolume .. ' % ',
				arrow = true,
				event = 'base_radio:set_vol',
                icon = 'fa-solid fa-volume-high',
			},
		    {
				title = TranslateCap('menu_disconnect_channel'),
				arrow = false,
				event = 'base_radio:leave',
                icon = 'fa-solid fa-right-from-bracket'
			}
		}
	})
	lib.showContext('radio_menu')
end

if Config.radio_item == false then
    RegisterCommand('toggleRadio', function()
        toggleRadio()
    end, false)

    RegisterKeyMapping('toggleRadio', TranslateCap('controls_toggle_radio'), 'keyboard', Config.radio_open_button)
end
--[[ fixed animation cancellation problem in ox_inventory
Citizen.CreateThread(function()
	while true do
		Citizen.Wait(3000)
		local count = exports.ox_inventory:Search('count', Config.radio_item_name)
		if count == 0 then
			TriggerEvent('base_radio:leave')
		end
	end
end)]]
