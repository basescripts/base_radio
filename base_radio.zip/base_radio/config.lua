Config = {}

Config.Locale = 'default'
Config.ox_notification = true

Config.radio_item = true
Config.radio_item_name = 'radio' 

Config.radio_open_button = 'F10'

Config.radio_default_volume = 50
Config.maximum_frequency = 999

Config.restricted_frequencies = true
Config.restricted_channels = 10
Config.restricted_channels_jobs_allowed = {
    'parkranger',
    'ambulance',
    'sheriff',
    'police',
    'army'
}