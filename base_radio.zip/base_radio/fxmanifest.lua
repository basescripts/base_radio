fx_version 'cerulean'
game 'gta5'
author 'Away » https://forum.cfx.re/u/awayofficial/'
version '2.0'
lua54 'yes'

client_script 'client/*.lua'

server_scripts {
	'server/*.lua'
}

shared_scripts {
	'@ox_lib/init.lua',
	'@es_extended/imports.lua',
	'@es_extended/locale.lua',
	'config.lua',
    'locales/*.lua'
}

dependency {
	'es_extended',
	'ox_lib',
	'pma-voice'
}