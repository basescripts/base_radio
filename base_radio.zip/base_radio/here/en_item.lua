Radio as an item [ox_inventory] ↓

————————————————————————————————

	['radio'] = {
		label = 'Radio',
		weight = 450,
		stack = false,
                allowArmed = true
	},
	
————————————————————————————————