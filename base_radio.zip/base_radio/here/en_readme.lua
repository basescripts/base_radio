Information ↓
• You will need es_extended, ox_lib, and pma-voice.
• Tested on ESX 1.10.10.
• Option to integrate with ox_inventory.
• Ability to select private channels for state agencies.
• Adjustable volume.

Please do not ↓
• Publish the script without permission, with or without modifications.