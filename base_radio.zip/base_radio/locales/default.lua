Locales['cs'] = {
    ['menu_title'] = 'Radio',
    ['menu_frequency'] = 'Frequency',
    ['menu_volume'] = 'Volume',
    ['menu_disconnect_channel'] = 'Disconnect the channel',
    ['menu_dialog_volume'] = 'Adjust the volume',
    ['menu_dialog_frequency'] = 'Set the frequency',
    ['controls_toggle_radio'] = 'Switch the radio'
}
